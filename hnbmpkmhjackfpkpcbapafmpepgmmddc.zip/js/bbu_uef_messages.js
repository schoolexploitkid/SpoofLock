globalThis.uefMessages=function(e){e.action==="webcam_restarted"&&chrome.runtime.sendMessage({message:"focus_page"})},chrome.runtime.onMessage.addListener(globalThis.uefMessages);
