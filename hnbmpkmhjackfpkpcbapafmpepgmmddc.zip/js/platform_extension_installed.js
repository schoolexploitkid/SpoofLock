(function(){window.postMessage({message:"honorlock:extension:installed"},"*")})();
