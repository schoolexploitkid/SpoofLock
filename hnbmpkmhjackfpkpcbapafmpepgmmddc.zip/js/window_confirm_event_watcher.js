(()=>{const o=window.confirm;window.confirm=function(...i){const n=o.apply(window,i);return window.postMessage({message:"honorlock:extension:window_confirm_event",is_confirmed:n},"*"),n}})();
